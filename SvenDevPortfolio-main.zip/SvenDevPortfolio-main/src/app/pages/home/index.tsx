import React from 'react';

const HomePage: React.FC = () => {
    return (
        <div>
            <h1>Hello World</h1>
        </div>
    );
};

export default HomePage;