# SvenDevPortfolio
The code for my portfolio website, showing off all my school and personal projects that i've developed/worked on.


## Project developed utilizing the following tools/frameworks
Typescript, CSS, Java, React
Springboot, Docker, Tailwind, Radix, 
npm, yarn

### Hosted via Render Hosting
on a free domain (hence why it sadly is run.place and not something more fitting like .dev), but hey its free and it works

#### Projects
All projects i've personally developed, which are not yet hosted online, i will be importing as a seperate module to be shown on the portfolio
Ofcourse the preferred method would be deploying each of these online, then linking to these projects, but for now that is not realistic.
They are imported straight from their respective github repositories (which will be linked in their respective paths) and i hope they will show my growth as a developer
and also show my strengths and capabilities. 